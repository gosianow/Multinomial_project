DM_package
==========

The Dirichlet Multinomial business
